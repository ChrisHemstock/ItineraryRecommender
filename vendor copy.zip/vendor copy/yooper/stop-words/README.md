# Stop Words
A collection of stop words from around the web and github. 

### Sources
This a list of sources that these stop words where taken from:

* https://sites.google.com/site/kevinbouge/stopwords-lists

### Contributions
Please submit a pull request with any changes you recommend. All **new** files must have a single word(s) per line.

### Verification & Validation
Some method(s) need to be created that allow for rating whether a stop word is valid or not. Any suggestions? 
